#include "Time.h"



Time::Time(int a, int b, int c)
{
	hour = a;
	minute = b;
	second = c;
}

int Time::compare(Time t)
{
	if (hour > t.hour)
	{
		return 1;
	}
	else if (hour == t.hour)
	{
		if (minute > t.minute)
		{
			return 1;
		}
		else if (minute == t.minute)
		{
			if (second > t.second)
			{
				return 1;
			}
			else if (second == t.second)
			{
				return 3;
			}
			else
				return 0;
		}
		else
			return 0;
	}
	else
		return 0;
}

void Time::increase(Time t)
{
	second = second + t.second;
	minute = minute + t.minute;
	hour = hour + t.hour;
	if (second >= 60) {
		minute += second / 60;
		second %= 60;
	}
	if (minute >= 60) {
		hour += minute / 60;
		minute %= 60;
	}
	if (hour >= 60){
		hour %= 24;
	}
}

int Time::gethour()
{
	return hour;
}

int Time::getminute()
{
	return minute;
}

int Time::getsecond()
{
	return second;
}

int Time::tellsection()
{
	if (hour < 7)
	{
		return 0;
	}
	else if (hour <= 8)
	{
		if (minute <= 20)
			return 10;		//�޳�
		else if (minute <= 35)
			return 11;		//��ȫ
		else if (minute <= 45)
			return 12;		//����
		else
			return 13;		//Σ��
	}
	else if (hour < 13)
		return 0;
	else if (hour <= 14) {
		if (minute <= 40)
			return 11;
		else if (minute <= 50)
			return 12;
		else
			return 13;
	}
	else if (hour < 18) {
			return 0;
	}
	else if (hour <= 19) {
		if (minute <= 5)
			return 11;
		else if (minute <= 15)
			return 12;
		else
			return 13;
	}
	else
		return 0;
}

String^ Time::telldaytime()
{
	if (hour < 6)
		return "�賿";
	else if (hour < 8)
		return "�糿";
	else if (hour < 11)
		return "����";
	else if (hour < 14)
		return "����";
	else if (hour < 18)
		return "����";
	else if (hour < 22)
		return "����";
	else
		return "��ҹ";
}

String^ Time::gettime()
{
	String^ shour = hour.ToString();
	String^	sminute = minute.ToString();
	String^	ssec = second.ToString();
	return shour + ":" + sminute + ":" + ssec;
}
