#include "Distance.h"


Distance::Distance(int a, int b, int c)
{
	stations = a;
	stations1 = b;
	stations2 = c;
}
Time Distance::estimate1(int status, Time t1)
{
	int aq[21] = {};
	for (int i = 0; i < 22; i++)
	{

		//aq[i]=regulartime1(status)[i];
	}
	int t2 = t1.gethour() * 3600 + t1.getminute() * 60 + t1.getsecond();
	for (int i = 0; i < 22; i++)
	{
		if (aq[i] > t2)
		{
			int t3 = aq[i] - t2;
			int hour1 = t3 / 3600;
			int minute1 = t3 / 60;
			int second1 = t3 % 60;
			if (minute1 >= 60)
				minute1 = minute1 - 60;
			Time deltatime(hour1, minute1, second1);
			t1.increase(deltatime);
			break;
		}
	}

	return t1;
}
Time Distance::regulartime1(int status, Time t1)
{
	return t1;
}
Time Distance::estimate(int a, Time t1)
{
	//t1 = estimate1(a, t1);
	//Time t3 = regulartime1(a, t1);
	if (a == 0)
	{
		int time = getmeter() / 8;
		int minute = time / 60;
		int hour = minute / 60;
		if (minute >= 60)
		{
			minute = minute - 60;

		}
		int second = time % 60;
		Time deltatime(hour, minute, second);
		Time intervaltime(0, 0, 16);
		for (int i = 0; i < stations; i++)
		{

			t1.increase(intervaltime);
		}
		t1.increase(deltatime);
		return t1;
	}
	else
	{
		int time = getmeter() / 6;
		int minute = time / 60;
		int hour = minute / 60;
		if (minute >= 60)
		{
			minute = minute - 60;

		}
		int second = time % 60;
		Time deltatime(hour, minute, second);
		Time intervaltime(0, 0, 22);
		for (int i = 0; i < stations; i++)
		{

			t1.increase(intervaltime);
		}
		t1.increase(deltatime);
		return t1;
	}

}

array<String ^>^ Distance::regulartime(int status)
{
	array<String^>^ timetable = gcnew array<String^>(60);
	Time starttime(7, 20, 0);
	Time endtime(20, 45, 0);
	Time lap(0, 15, 0);
	int time1 = starttime.gethour() * 3600 + starttime.getminute() * 60 + starttime.getsecond();
	//��������
	if (status == 0)
	{
		Time deltatime(0, 1, 10);
		Time intervaltime(0, 0, 20);
		for (int i = 0; i < stations; i++) {
			starttime.increase(deltatime);
			starttime.increase(intervaltime);
			endtime.increase(deltatime);
			endtime.increase(intervaltime);
		}
		timetable[0] = starttime.gettime();
		int i = 1;
		while (starttime.gethour() <= endtime.gethour())
		{
			starttime.increase(lap);
			timetable[i] = starttime.gettime();
			i++;
		}
		return timetable;
	}
	else//��������
	{
		Time deltatime(0, 1, 5);
		Time intervaltime(0, 0, 16);
		for (int i = 0; i < stations; i++) {
			starttime.increase(deltatime);
			starttime.increase(intervaltime);
			endtime.increase(deltatime);
			endtime.increase(intervaltime);
		}
		timetable[0] = starttime.gettime();
		int i = 1;
		while (starttime.gethour() <= endtime.gethour())
		{
			starttime.increase(lap);
			timetable[i] = starttime.gettime();
			i++;
		}
		return timetable;
	}

}


int Distance::getmeter()
{
	int dis = 0;
	int array[22] =
	{
		300,400,303,227,485,624,480,335,600,320,260,351,1000,1200,1800,1500,560,400,860,590,962,200
	};
	for (int i = stations2 - 1; i < stations1; i++)
	{
		dis += array[i];
	}
	return dis;
}
int Distance::getmeter1()
{
	int dis1 = 0;
	int dis2 = 0;
	int array[22] =
	{
		300,400,303,227,485,624,480,335,600,320,260,351,1000,1200,1800,1500,560,400,860,590,962,200
	};
	for (int i = stations2 - 1; i < stations1; i++)
	{
		dis1 += array[i];
	}
	for (int i = stations1 - 1; i > stations2 - 1; i--)
	{
		dis2 += array[i];
	}
	if (dis1 > dis2)
		return dis1;
	else
		return dis2;
}
