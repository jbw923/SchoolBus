﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolBus
{
    public partial class Form1 : Form
    {
        static int status = 0;
        public Form1()
        {
            InitializeComponent();
            string[] stations = {
            "信息学部二食堂",
            "大学生活动中心",
            "青年楼",
            "武大附中高中部",
            "东中区家属楼",
            "梅园食堂",
            "珞珈山庄",
            "枫园十四舍",
            "留学生院",
            "经管院",
            "法学院（外院）",
            "湖滨食堂",
            "社科院",
            "工学部网球场",
            "一站式学生事务与发展中心",
            "明珠园",
            "珞珈自强超市（工菜）",
            "计算机学院",
            "教五楼",
            "校大门",
            "信息学部游泳池",
            "国际软件学院",
            "信息学部二食堂"};
            comboBox1.DataSource = stations.Clone();
            comboBox2.DataSource = stations.Clone();
            comboBox3.DataSource = stations.Clone();
            comboBox4.DataSource = stations.Clone();
            comboBox5.DataSource = stations.Clone();
            if (getWeather() == 0)
            {
                status = 1;
            }
            else
                status = 0;
        }

        public int getWeather()
        {
            try
            {
                cn.com.webxml.www.WeatherWebService w = new cn.com.webxml.www.WeatherWebService();
                //把webservice当做一个类来操作  
                string[] s = new string[23];//声明string数组存放返回结果  
                s = w.getWeatherbyCityName("武汉");
                //以文本框内容为变量实现方法getWeatherbyCityName  
                label4.Text = s[1] + " " + s[6];
                textBox1.Text = s[10];
                if (s[6].Contains("雨") || s[6].Contains("雪") || s[6].Contains("雹"))
                    return 0;
                else
                    return 1;
            }
            catch (Exception)
            {
                if(MessageBox.Show("获取天气数据失败。\n你可以选择重试或忽略并继续。\n若忽略，软件将默认今日天气状况为晴天，预测时间可能不准确。\n你也可以选择稍后在主页点击刷新按钮重试。",
                                    "(╬￣皿￣)=○错误",
                                    MessageBoxButtons.RetryCancel,
                                    MessageBoxIcon.Exclamation,
                                    MessageBoxDefaultButton.Button1,
                                    MessageBoxOptions.ServiceNotification) == DialogResult.Retry)
                    getWeather();
                return 1;
            }
           
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = "欢迎使用本软件！(✪ω✪)当前时间："+DateTime.Now.ToString("HH:mm:ss");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
            timer1.Start();
            toolStripStatusLabel1.Text = "首页";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (getWeather() == 0)
            {
                status = 1;
            }
            else
                status = 0;
        }

        private void 时间预测ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Visible = true;
            panel3.Visible = false;
            panel4.Visible = false;
            toolStripStatusLabel1.Text = "当前时间预测";
        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 ab1 = new AboutBox1();
            ab1.Show();
        }

        private void 首页ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            toolStripStatusLabel1.Text = "首页";
        }

        private void 查询常规时间ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = true;
            panel4.Visible = false;
            toolStripStatusLabel1.Text = "查询常规时间";
        }

        private void 建议路线ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = true;
            toolStripStatusLabel1.Text = "建议路线";
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int distan;
            Time nowtime = new Time(int.Parse(DateTime.Now.Hour.ToString()), int.Parse(DateTime.Now.Minute.ToString()), int.Parse(DateTime.Now.Second.ToString()));
            distan = comboBox5.SelectedIndex - comboBox4.SelectedIndex;
            if (distan <= 0)
                MessageBox.Show("要么你选的站顺序不对，要么就是一个站。重选吧！",
                                "(￣へ￣）错误",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation,
                                MessageBoxDefaultButton.Button1,
                                MessageBoxOptions.ServiceNotification);
            else
            {
                Distance dist1 = new Distance(distan);
                if (dist1.estimate(status, nowtime).tellsection() == 11)
                    MessageBox.Show("时间还早，坐车莫得问题。",
                                    "(￣▽￣)~*提示",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information,
                                    MessageBoxDefaultButton.Button1,
                                    MessageBoxOptions.ServiceNotification);
                else if (dist1.estimate(status, nowtime).tellsection() == 12)
                    MessageBox.Show("时间紧迫，如还等不到大循环就坐工学部校车咯\n或者直接找一辆共享单车哦。",
                                    "(；´д｀)ゞ提示",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information,
                                    MessageBoxDefaultButton.Button1,
                                    MessageBoxOptions.ServiceNotification);
                else if (dist1.estimate(status, nowtime).tellsection() == 13)
                    MessageBox.Show("要迟到啦！找辆单车赶紧跑吧！",
                                    "/(ㄒoㄒ)/~~提示",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information,
                                    MessageBoxDefaultButton.Button1,
                                    MessageBoxOptions.ServiceNotification);
                else if (dist1.estimate(status, nowtime).tellsection() == 0)
                    MessageBox.Show("不是高峰时段欧，坐车骑车无压力。",
                                    "(oﾟ▽ﾟ)o  提示",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information,
                                    MessageBoxDefaultButton.Button1,
                                    MessageBoxOptions.ServiceNotification);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string texttoshow="";
            Distance d1 = new Distance(comboBox3.SelectedIndex);
            for (int i = 0; i < 60; i++)
            {
                texttoshow = texttoshow + d1.regulartime(status)[i] + "\t";
                if (i % 4 == 0)
                {
                    texttoshow += "\n";
                }
            }
            MessageBox.Show(texttoshow,
                    "(｀・ω・´)时间表",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information,
                    MessageBoxDefaultButton.Button1,
                    MessageBoxOptions.ServiceNotification);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int distan;
            distan = comboBox2.SelectedIndex - comboBox1.SelectedIndex;
            if (distan <= 0)
                MessageBox.Show("要么你选的站顺序不对，要么就是一个站。重选吧！",
                                "(￣へ￣）错误",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation,
                                MessageBoxDefaultButton.Button1,
                                MessageBoxOptions.ServiceNotification);
            else
            {
                Distance dis1 = new Distance(distan);
                Time nowtime = new Time(int.Parse(DateTime.Now.Hour.ToString()), int.Parse(DateTime.Now.Minute.ToString()), int.Parse(DateTime.Now.Second.ToString()));
                if (dis1.estimate(status, nowtime).tellsection() == 11)
                    MessageBox.Show("预计到达时间：" + dis1.estimate(status, nowtime).gettime() + "\n时间还早，坐车莫得问题。",
                                    "(￣▽￣)~*提示",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information,
                                    MessageBoxDefaultButton.Button1,
                                    MessageBoxOptions.ServiceNotification);
                else if (dis1.estimate(status, nowtime).tellsection() == 12)
                    MessageBox.Show("预计到达时间：" + dis1.estimate(status, nowtime).gettime() + "\n时间紧迫，如还等不到大循环就坐工学部校车咯\n或者直接找一辆共享单车哦。",
                                    "(；´д｀)ゞ提示",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information,
                                    MessageBoxDefaultButton.Button1,
                                    MessageBoxOptions.ServiceNotification);
                else if (dis1.estimate(status, nowtime).tellsection() == 13)
                    MessageBox.Show("预计到达时间：" + dis1.estimate(status, nowtime).gettime() + "\n要迟到啦！找辆单车赶紧跑吧！",
                                    "/(ㄒoㄒ)/~~提示",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information,
                                    MessageBoxDefaultButton.Button1,
                                    MessageBoxOptions.ServiceNotification);
                else if (dis1.estimate(status, nowtime).tellsection() == 0)
                    MessageBox.Show("预计到达时间：" + dis1.estimate(status, nowtime).gettime() + "\n不是高峰时段欧，坐车骑车无压力。",
                                    "(oﾟ▽ﾟ)o  提示",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information,
                                    MessageBoxDefaultButton.Button1,
                                    MessageBoxOptions.ServiceNotification);
            }
        }
    }
}
