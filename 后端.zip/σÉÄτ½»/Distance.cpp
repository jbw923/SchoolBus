#include "Distance.h"
#include<stdlib.h>


Distance::Distance(int a)
{
	stations = a;
}

Time Distance::estimate(int a,Time t1)
{
	if (a == 0)
	{
		int speed = 5;
		int time;
		int minute;
		int second;
		time = getmeter() / 5;
		minute = time / 60;
		second = time % 60;
		Time deltatime(0, minute, second);
		Time intervaltime(0, 0, 16);
		for (int i = 0; i < stations; i++)
		{
			//t1.increase(deltatime);
			t1.increase(intervaltime);
		}
		t1.increase(deltatime);
		return t1;
	}
	else
	{
		int speed = 4;
		int time;
		int minute;
		int second;
		time = getmeter() / 4;
		minute = time / 60;
		second = time % 60;
		Time deltatime(0, minute, second);
		Time intervaltime(0, 0, 22);
		for (int i = 0; i < stations; i++)
		{
			
			t1.increase(intervaltime);
		}
		t1.increase(deltatime);
		return t1;
	}
}

array<String ^>^ Distance::regulartime(int status)
{
	array<String^>^ timetable = gcnew array<String^>(60);
	Time starttime(7, 20, 0);
	Time lap(0, 12, 43);
	if (status==0)
	{
		Time deltatime(0, 1, 5);
		Time intervaltime(0, 0, 16);
		for (int i = 0; i < stations; i++) {
			starttime.increase(deltatime);
			starttime.increase(intervaltime);
		}
		timetable[0] = starttime.gettime();
		for (int i = 1; i < 60; i++)
		{
			starttime.increase(lap);
			timetable[i] = starttime.gettime();
		}
		return timetable;
	}
	else {
		Time deltatime(0, 1, 20);
		Time intervaltime(0, 0, 22);
		for (int i = 0; i < stations; i++) {
			starttime.increase(deltatime);
			starttime.increase(intervaltime);
		}
		timetable[0] = starttime.gettime();
		for (int i = 1; i < 60; i++)
		{
			starttime.increase(lap);
			timetable[i] = starttime.gettime();
		}
		return timetable;
	}
}

int Distance::getmeter()
{
	int dis=0;
	//return stations*400;
	for (int i = 0; i < stations; i++)
	{
		
		dis +=( rand()%(301)) + 200;
	}
	return dis;
}
